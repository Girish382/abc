import java.io.*;
import java.util.*;

class CryptoArithmetic {

	public static boolean isSolvable(String[] words,
									String result)
	{
		int mp[] = new int[26];

		int used[] = new int[10];

		int Hash[] = new int[26];

		int CharAtfront[] = new int[26];

		Arrays.fill(mp, -1);
		Arrays.fill(used, 0);
		Arrays.fill(Hash, 0);
		Arrays.fill(CharAtfront, 0);

		StringBuilder uniq = new StringBuilder();

		for (String word : words) {
			for (int i = 0; i < word.length(); i++) {
				char ch = word.charAt(i);
				Hash[ch - 'A'] += (int)Math.pow(
					10, word.length() - i - 1);

				if (mp[ch - 'A'] == -1) {

					mp[ch - 'A'] = 0;
					uniq.append((char)ch);
				}

				if (i == 0 && word.length() > 1) {

					CharAtfront[ch - 'A'] = 1;
				}
			}
		}

		for (int i = 0; i < result.length(); i++) {

			char ch = result.charAt(i);

			Hash[ch - 'A'] -= (int)Math.pow(
				10, result.length() - i - 1);

			if (mp[ch - 'A'] == -1) {
				mp[ch - 'A'] = 0;
				uniq.append((char)ch);
			}

			if (i == 0 && result.length() > 1) {
				CharAtfront[ch - 'A'] = 1;
			}
		}

		Arrays.fill(mp, -1);

		return solve(uniq, 0, 0, mp, used, Hash,
					CharAtfront);
	}

	public static boolean solve(
		StringBuilder words, int i,
		int S, int[] mp, int[] used,
		int[] Hash,
		int[] CharAtfront)
	{
		if (i == words.length())

			return (S == 0);

		char ch = words.charAt(i);

		int val = mp[words.charAt(i) - 'A'];

		if (val != -1) {

			return solve(words, i + 1,
						S + val * Hash[ch - 'A'],
						mp, used,
						Hash, CharAtfront);
		}

		boolean x = false;

		for (int l = 0; l < 10; l++) {

			if (CharAtfront[ch - 'A'] == 1
				&& l == 0)
				continue;

			if (used[l] == 1)
				continue;

			mp[ch - 'A'] = l;

			used[l] = 1;

			x |= solve(words, i + 1,
					S + l * Hash[ch - 'A'],
					mp, used, Hash, CharAtfront);

			mp[ch - 'A'] = -1;

			used[l] = 0;
		}

		return x;
	}

	public static void main(String[] args)
	{
		String[] arr
			= { "SIX", "SEVEN", "SEVEN" };
		String S = "TWENTY";

		if (isSolvable(arr, S))
			System.out.println("Yes");
		else
			System.out.println("No");
	}
}
